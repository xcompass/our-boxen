# Picasa Puppet Module for Boxen

Installs Google Picasa.

[![Build Status](https://travis-ci.org/boxen/puppet-picasa.png?branch=master)](https://travis-ci.org/boxen/puppet-picasa)

## Usage

include picasa

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
